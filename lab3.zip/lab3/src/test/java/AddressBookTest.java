import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.LinkedList;

import static org.junit.Assert.*;

public class AddressBookTest {

    @org.junit.Test
    public void addBuddy() {
        BuddyInfo b1 = new BuddyInfo("Beshr","Beshr05@gmail.com",21);
        AddressBook l1 = new AddressBook();
        l1.addBuddy(b1);
        assert(!(l1.getBuddyList().isEmpty()));
    }

//    @org.junit.Test
//    public void removeBuddy() {
//        BuddyInfo b1 = new BuddyInfo("Beshr","Beshr05@gmail.com",21);
//        AddressBook l1 = new AddressBook();
//        l1.addBuddy(b1);
//        l1.removeBuddy(b1);
//        assert(l1.getBuddyList().isEmpty());
//    }

//    @org.junit.Test
//    public void getBuddyList() {
//        AddressBook l1 = new AddressBook();
//        assert (l1.getBuddyList() instanceof LinkedList);
//    }

//    @Test
//    public void printList() {
//        BuddyInfo b1 = new BuddyInfo("Beshr","Beshr05@gmail.com",21);
//        AddressBook l1 = new AddressBook();
//        l1.addBuddy(b1);
//        System.out.println("Expected output:\n");
//        System.out.println("Buddies in the list:");
//        System.out.println("Beshr");
//        System.out.println("\n\n\nActual output:\n");
//        l1.printList();
//
//    }
//    @Test
//    public void persistAddressBook(){
//        EntityManagerFactory emf= Persistence.createEntityManagerFactory("labPersistenceUnit");
//        EntityManager em = emf.createEntityManager();
//        em.getTransaction().begin();
//        AddressBook addressBook = new AddressBook();
//        em.persist(addressBook);
//        BuddyInfo b =new BuddyInfo("Beshr","Beshr05@gmail.com",21);
//        LinkedList<BuddyInfo> list = new LinkedList<BuddyInfo>();
//        list.add(b);
//        addressBook.setBuddyList(list);
//        em.persist(b);
//        em.getTransaction().commit();
//        Query q = em.createQuery("SELECT p FROM AddressBook p");
//        em.close();
//        emf.close();
//
//    }
}