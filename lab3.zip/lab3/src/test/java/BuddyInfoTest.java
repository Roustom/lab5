import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import static org.junit.Assert.*;

public class BuddyInfoTest {
    private BuddyInfo b;
    @Before
    public void setUp() throws Exception {
         b = new BuddyInfo("Beshr", "Beshr05@gmail.com", 21);
    }

    @Test
    public void getName() {
        assert(b.getName().equals("Beshr"));
    }

    @Test
    public void setName() {
        b.setName("Saad");
        assert(b.getName().equals("Saad"));
    }

    @Test
    public void getEmail() {
        assert (b.getEmail().equals("Beshr05@gmail.com"));
    }

    @Test
    public void setEmail() {
        b.setEmail("BBeshr04@gmail.com");
        assert (b.getEmail().equals("BBeshr04@gmail.com"));
    }

    @Test
    public void getAge() {
        assert (b.getAge()==21);
    }

    @Test
    public void setAge() {
        b.setAge(22);
        assert (b.getAge()==22);
    }

    @Test
    public void persistBuddyInfo(){
        EntityManagerFactory emf= Persistence.createEntityManagerFactory("labPersistenceUnit");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        BuddyInfo b =new BuddyInfo("Beshr","Beshr05@gmail.com",21);
        em.persist(b);
        em.getTransaction().commit();
        Query q = em.createQuery("SELECT p FROM BuddyInfo p");

        em.close();
        emf.close();

    }
}