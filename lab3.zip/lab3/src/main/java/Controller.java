import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller {
    private AddressBook model;
    private View  view;

    public Controller(View v, AddressBook m){
        model = m;
        view = v;

        this.view.addBuddyListener(new Listener());
    }
    class Listener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println(e.getActionCommand());
            if(e.getActionCommand().equals("Add Buddy")){
                System.out.println("correct");

                model.addBuddy(new BuddyInfo("testName","testEmail@test.com",21));
                view.setText(model.returnText());
            }else if(e.getActionCommand().equals("Delete Buddy")){
                System.out.println("correct");
                model.removeBuddy();
                view.setText(model.returnText());
            }
        }
    }
    public static void main(String[] args){
        View v = new View();
        v.init();
        AddressBook m = new AddressBook();
        Controller c = new Controller(v,m);

    }

}
