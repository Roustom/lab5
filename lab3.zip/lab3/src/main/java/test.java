public class test {
    private int[] arr={1,2,3,4,5};

    public int max(int[] arr){
        return 0;
    }

    public  void main(String[] args) {
        System.out.println(this.max(this.arr));
    }
}
