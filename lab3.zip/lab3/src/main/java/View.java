import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Observable;
import java.util.Observer;

public class View {


    private JFrame f;
    private JButton addBuddyButton;
    private JButton deleteBuddyButton;
    private JTextArea display;
    public View(){
    }


    public void setText(String txt){
        display.setText(txt);
    }

    public void addBuddyListener(ActionListener listenerForButton) {
        addBuddyButton.addActionListener(listenerForButton);
        deleteBuddyButton.addActionListener(listenerForButton);


    }

    public void init() {
        f = new JFrame();
        f.setLayout(new GridBagLayout());

        display= new JTextArea("Empty AddressBook");
        display.setBounds(0,200,300,300);


        addBuddyButton= new JButton("Add Buddy");

        deleteBuddyButton= new JButton("Delete Buddy");



        f.add(addBuddyButton);
        addBuddyButton.setBounds(0,380,400,40);
        f.add(deleteBuddyButton);
        deleteBuddyButton.setBounds(0,420,400,40);

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 40;      //make this component tall
        c.weightx = 0.0;
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 1;
        f.add(display,c);

        f.setSize(400,500);
        f.setVisible(true);
    }
}
